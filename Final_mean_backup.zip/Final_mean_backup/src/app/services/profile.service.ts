import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import IProfile from '../interface/profile';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  constructor(private http : HttpClient) { }

  profile(profile : IProfile) {
    return this.http.post("http://localhost:4500/profile", profile)
   }
}
