import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import IAddress from '../interface/address';

@Injectable({
  providedIn: 'root'
})
export class AddressService {

  constructor(private http : HttpClient) { }

  address(address : IAddress) {
    return this.http.post("http://localhost:4500/adress", address)
   }
}
