import { Injectable } from '@angular/core';
import IRegister from '../interface/register';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private http : HttpClient) { }

  getRegisterUsers(firstName : string){
    return this.http.get(`http://localhost:4500/register/${firstName}`)
  }
  register( firstName : string ,data : IRegister) {
    return this.http.post(`http://localhost:4500/register/${firstName}`, data)
   }
}
