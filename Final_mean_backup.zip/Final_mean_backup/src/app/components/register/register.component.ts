import { Component, OnInit , Input } from '@angular/core';
import IRegister from 'src/app/interface/register';
import { RegisterService } from 'src/app/services/register.service';
import { FormControl, FormGroup, AbstractControl , Validators} from '@angular/forms';
import { Router } from '@angular/router'
import CompareValidator from 'src/app/validators/compare';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  form = new FormGroup({
    firstName :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32) ]),
    lastName :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32) ]),
    email :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32), Validators.email ]),
    password :new  FormControl('', [Validators.required , Validators.minLength(6), Validators.maxLength(32) ]),
    confirmpassword :new  FormControl('' , [Validators.required , Validators.minLength(6), Validators.maxLength(32) ]),    
  }, [CompareValidator("password" , "confirmpassword")] )

  constructor(private registerform : RegisterService , private router : Router) { }
  @Input() fName !: string;
  ngOnInit(): void {
    this.registerform.getRegisterUsers(this.fName).subscribe((data)=>{
      console.log(data);
      this.form.patchValue(data);
    }
    )
  }

  registerForm(){
    console.log(this.form.value)
    this.registerform.register(this.fName ,this.form.value).subscribe((data)=>{
alert("New product added");
this.router.navigateByUrl(`/register/${this.firstName}`)
    
  })
}
get firstName() : AbstractControl | null {
  return this.form.get("firstName")
}
get lastName() : AbstractControl | null {
  return this.form.get("lastName")
}
get email() : AbstractControl | null {
  return this.form.get("email")
}

get password() : AbstractControl | null {
  return this.form.get("password")
}
get confirmpassword() : AbstractControl | null {
  return this.form.get("confirmpassword")
}

get editForm() {
  return this.form
}
}
