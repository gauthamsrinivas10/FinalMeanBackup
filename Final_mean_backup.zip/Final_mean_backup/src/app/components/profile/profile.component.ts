import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import IAddress from 'src/app/interface/address';
import IProfile from 'src/app/interface/profile';
import { AddressService } from 'src/app/services/address.service';
import { ProfileService } from 'src/app/services/profile.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private profileForm : ProfileService , private addressForm : AddressService) { }
  form!: IProfile; 
  formaddress!: IAddress; 
  ngOnInit(): void {
  }
  profileData = {
    
    firstName:  "John",
    lastName : "Walker",    
    phone : "8933246123",
    interest : "Apple , Samsung , Laptop",
    address : "83,Fifth Avenue,New York"
    
  }

  addressData = {
    
    streetAddress:  "83 Fifth Ave",
    city : "Bellevue",    
    state : "WA",
    zipCode : "98200"
    
  }

  

  profile(form : NgForm){
    console.log(this.form, form)
    this.profileForm.profile(this.form).subscribe(()=>{
alert("New Profile Update added");
this.form = {
  firstName : "",
  lastName : "",
  phone : "" ,
  interest : "",
  address : ""

}
    
  })
  }

  address(form : NgForm){
    console.log(this.form, form)
    this.addressForm.address(this.formaddress).subscribe(()=>{
alert("New Profile Update added");
this.formaddress = {
  streetAddress:  "",
    city : "",    
    state : "",
    zipCode : ""

}
    
  })
  }
  
  showEdit = false;
  Edit(){
  this.showEdit = true
  }

  Save(){
    this.showEdit = false
  }
}
