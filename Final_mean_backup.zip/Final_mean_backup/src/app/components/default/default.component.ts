import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-default',
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.css']
})
export class DefaultComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  navigatetoHome(){
    this.router.navigateByUrl("/")
  }
  navigateProfile(){
    this.router.navigateByUrl("/profile")
  }
  navigatetoAdmin(){
    this.router.navigateByUrl("/admin")
  }
  navigatetoLogin(){
    this.router.navigateByUrl("/login")
  }
  navigatetoProducts(){
    this.router.navigateByUrl("/products")
  }
  navigateteCart(){
    this.router.navigateByUrl("/cart")
  }
}
