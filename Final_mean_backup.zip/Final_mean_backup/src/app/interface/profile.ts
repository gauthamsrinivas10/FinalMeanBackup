export default interface IProfile {
    "firstName": string
    "lastName": string    
    "phone": string   
    "interest": string
    "address": string    
}